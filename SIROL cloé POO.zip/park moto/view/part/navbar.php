<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="http://localhost">exercice PHP</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php?controller=motos&action=list">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php?controller=motos&action=add">add</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php?controller=security&action=logout">deconnexion</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        type de motos
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                        <li><a class="dropdown-item" href="index.php?controller=motos&action=list&type=Enduro">Enduro</a></li>
                        <li><a class="dropdown-item" href="index.php?controller=motos&action=list&type=Custom">Custom</a></li>
                        <li><a class="dropdown-item" href="index.php?controller=motos&action=list&type=Sportive">Sportive</a></li>
                        <li><a class="dropdown-item" href="index.php?controller=motos&action=list&type=Roadster">Roadster</a></li>
                        <li><a class="dropdown-item" href="index.php?controller=motos&action=list">toute</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
