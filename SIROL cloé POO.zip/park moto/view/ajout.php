<html lang="french">
<head>
    <title> exo  </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<?php require 'view/part/navbar.php' ?>
<div class="container">
    <h1>
        ajouter un véhicule
    </h1>
</div>



<form method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label> marque </label>
        <input class="form-control <?php if(array_key_exists('mark',$errors)){echo 'is-invalid';} ?>" type="text" name="mark"
               value="<?php if(array_key_exists('mark',$_POST)){echo $_POST['mark'];} ?>">
        <?php if (array_key_exists('mark',$errors)){
            echo '<div class="invalid-feedback">',$errors['mark'],'</div>';
        }?>
    </div>
    <div class="form-group">
        <label> modele </label>
        <input class="form-control <?php if(array_key_exists('model',$errors)){echo 'is-invalid';} ?>" type="text" name="model"
        value="<?php if(array_key_exists('model',$_POST)){echo $_POST['model'];} ?>">
        <?php if (array_key_exists('model',$errors)){
            echo '<div class="invalid-feedback">',$errors['model'],'</div>';
        }?>
    </div>
    <div class="form-group">
        <label> type </label>
        <select class="form-select <?php if(array_key_exists('type',$errors)){echo 'is-invalid';} ?>" name="type">
            <option value=""> selectioner une type </option>
            <?php
                foreach (moto::$allowedtype as $type){
                    $selected = '';
                    if ($_POST['type'] == $type){
                        $selected = 'selected';
                    }
                    echo '<option ',$selected,' value="',$type,'"> ',$type,' </option>';
                }
             if (array_key_exists('type',$errors)){
                echo '<div class="invalid-feedback">',$errors['type'],'</div>';
            }?>
        </select>
    </div>

    <div>
        <label> image (optionel)</label>
        <input type="file" name="picture" class="form-control <?php if(array_key_exists('picture',$errors)){echo 'is-invalid';} ?>
        " value="<?php if(array_key_exists('picture',$_POST)){echo $_POST['picture'];} ?>">
        <?php if (array_key_exists('picture',$errors)){
            echo '<div class="invalid-feedback">',$errors['picture'],'</div>';
        }?>
    </div>

    <input type="submit">
</form>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
