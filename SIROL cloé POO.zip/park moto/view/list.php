<html lang="french">
<head>
    <title> examen blanc </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<?php
require 'view/part/navbar.php'
?>
<div class="container">
    <h1>
        liste des motos
    </h1>
</div>
<table class="table">
    <thead>
    <tr>
        <th scope="col">id</th>
        <th scope="col">marque</th>
        <th scope="col">modele</th>
        <th scope="col">type de moto</th>
        <th scope="col">image</th>
        <th scope="col">action</th>
    </tr>
    </thead>
    <tbody>
<?php
foreach ($allmotos as $allmoto) {
    echo('
        <tr>
            <th scope="row">' . $allmoto->getId() . '</th>
            <td>' . $allmoto->getMark() . '</td>
            <td>' . $allmoto->getModel() . '</td>
            <td>' . $allmoto->getType() . '</td>
            
    
            <td><img style="max-width: 100px" class="img img-thumbnail" src="'.$allmoto->getPicture().'"></td>
            <td>
                <a class="btn btn-info" href="index.php?controller=motos&action=detail&id='.$allmoto->getId().'">voir detail</a><br>
                <a class="btn btn-danger" href="index.php?controller=motos&action=delete&id='.$allmoto->getId().'">supprimer</a><br>
        </tr>
    ');
}
?>
    </tbody>
</table>
<?php
    if($empty){
        echo '<h2>',$message,'</h2>';
    }
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
