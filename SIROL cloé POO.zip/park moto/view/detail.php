<html>
<head>
    <title> exo  </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<?php
require 'view/part/navbar.php'
?>
<div class="container">
    <h1>
        <?php
        echo $onemoto->getModel();
        ?>
    </h1>

    <a class="btn btn-success" href="index.php?controller=motos&action=list">revenir en arrière</a>

    <div class="col-md-12 text-center">
        <h2><?php echo $onemoto->getMark()?></h2>
        <img src="<?php echo $onemoto->getPicture(); ?>">
        <p><?php echo $onemoto->getType(); ?></p><br>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>