<?php
session_start();
spl_autoload_register(function($classname){
    if (str_ends_with($classname,'Controller')){
        require 'controller/'.$classname.'.php';
    }
    elseif (str_ends_with($classname,'Manager')){
        require 'manager/'.$classname.'.php';
    }else{
        require 'class/'.$classname.'.php';
    }
});




