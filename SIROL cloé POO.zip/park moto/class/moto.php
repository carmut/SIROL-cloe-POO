<?php

class moto
{
    public static $allowedimage = ['image/jpeg','image/png'];
    private $id;
    private $model;
    private $type;
    private $picture;
    private $mark;
    public static $allowedtype = ['Enduro','Custom','Sportive','Roadster'];
    public function __construct($id, $model, $type, $picture, $mark)
    {
        $this->id = $id;
        $this->model = $model;
        $this->type = $type;
        $this->picture = $picture;
        $this->mark = $mark;
    }
    public function getId()
    {
        return $this->id;
    }
    public function setId($id): void
    {
        $this->id = $id;
    }
    public function getModel()
    {
        return $this->model;
    }
    public function setModel($model): void
    {
        $this->model = $model;
    }
    public function getType()
    {
        return $this->type;
    }
    public function setType($type): void
    {
        $this->type = $type;
    }
    public function getPicture()
    {
        return $this->picture;
    }
    public function setPicture($picture): void
    {
        $this->picture = $picture;
    }
    public function getMark()
    {
        return $this->mark;
    }
    public function setMark($mark): void
    {
        $this->mark = $mark;
    }

}