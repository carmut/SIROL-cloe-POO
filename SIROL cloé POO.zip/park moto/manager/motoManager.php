<?php

class motoManager extends dbManager
{
    public function getall(){
        $tabobjet = [];
        $querry = $this->bdd->query('SELECT * FROM motos');
        $results = $querry->fetchAll();

        foreach ($results as $result){
            $tabobjet[] = new moto(
                $result['id'],
                $result['model'],
                $result['type'],
                $result['picture'],
                $result['mark']
            );

        }
        return $tabobjet;
    }
    public function getone($id)
    {
        $querry = $this->bdd->prepare('SELECT * FROM motos WHERE id= :id');
        $querry->execute(['id'=>$id]);
        $result = $querry->fetch();

        $moto = null;

        if($result){
            $moto = new moto(
                $result['id'],
                $result['model'],
                $result['type'],
                $result['picture'],
                $result['mark']
            );
        }

        return $moto;
    }
    public function delete($id)
    {
        $querry = $this->bdd->prepare('DELETE FROM motos WHERE id= :id');
        $querry->execute(['id'=>$id]);
    }
    public function insert(moto $moto)
    {
        if($moto->getPicture()!=''){
            $querry = $this->bdd->prepare("INSERT INTO motos (model,type,picture,mark) VALUES (:model,:type,:picture,:mark)");
            $querry->execute([
                'model'=>$moto->getModel(),
                'type'=>$moto->getType(),
                'picture'=>$moto->getPicture(),
                'mark'=>$moto->getMark()
            ]);
        }else{
            $querry = $this->bdd->prepare("INSERT INTO motos (model,type,mark) VALUES (:model,:type,:mark)");
            $querry->execute([
                'model'=>$moto->getModel(),
                'type'=>$moto->getType(),
                'mark'=>$moto->getMark()
            ]);
        }
    }

    public function getbytype($type)
    {
        $tabobjet = [];
        $querry = $this->bdd->prepare('SELECT * FROM motos WHERE type= :type');
        $querry->execute(['type'=>$type]);
        $results = $querry->fetchAll();
        if (!empty($results)){
            foreach ($results as $result){
                $tabobjet[] = new moto(
                    $result['id'],
                    $result['model'],
                    $result['type'],
                    $result['picture'],
                    $result['mark']
                );
            }
        }
        return $tabobjet;
    }
}