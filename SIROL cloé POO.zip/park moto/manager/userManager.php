<?php

class userManager extends dbManager
{
    public function findbyusername($username){
        $query = $this->bdd->prepare('SELECT * FROM users WHERE username= :username');
        $query->execute(['username'=>$username]);
        $result  = $query->fetch();

        if ($result){
            $user = new user($result['id'],$result['username'],$result['password']);
            return $user;
        }
    }
}