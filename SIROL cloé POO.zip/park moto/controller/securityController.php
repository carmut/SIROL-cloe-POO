<?php

class securityController
{
    private $usermanager;
    public function __construct()
    {
        $this->usermanager = new userManager();
    }
    public function login()
    {
        $errors = false;
        if ($_SERVER['REQUEST_METHOD'] == 'POST'){
            $user = $this->usermanager->findbyusername($_POST['username']);
            if ($user){
                if (password_verify($_POST['password'],$user->getPassword())){

                    $_SESSION['user'] = serialize($user);
                    header('Location: index.php?controller=motos&action=list');
                } else {
                    $errors = true;
                }
            } else {
                $errors = true;
            }
        }
        require 'view/login.php';
    }

    public function logout()
    {
        session_destroy();
        header('Location: index.php?controller=security&action=login');
    }
    public function page_non_trouve(){
        require 'view/404.php';
    }
}