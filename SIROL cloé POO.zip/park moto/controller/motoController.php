<?php

class motoController
{
    private $motoManager;
    public function __construct()
    {
        $this->motoManager = new motoManager();
    }

    public function getallmoto()
    {
        $empty = false;
        $allmotos = $this->motoManager->getall();
        require 'view/list.php';
        if(!$allmotos){
            $empty = true;
            $message = 'il n\'y a aucune moto d\'enregistré';
        }
    }

    public function getdetail($id)
    {
        $onemoto = $this->motoManager->getone($id);
        require 'view/detail.php';
    }

    public function delete($id)
    {
        $this->motoManager->delete($id);
        header('Location: index.php?controller=motos&action=list');
    }

    public function add(){
        $errors = [];

        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $errors = $this->isvalid();
            if (count($errors) == 0){

                if (!empty($_FILES)){
                    $download = 'download/' . uniqid() . $_FILES['picture']['name'];
                    move_uploaded_file($_FILES['picture']['tmp_name'],$download);
                    $moto = new moto(null,$_POST['model'],$_POST['type'],$download,$_POST['mark']);
                }else{
                    $moto = new moto(null,$_POST['model'],$_POST['type'],null,$_POST['mark']);
                }
                $this->motoManager->insert($moto);
                header('Location: index.php?controller=motos&action=list');
            }
        }

        require 'view/ajout.php';
    }
    private function isvalid(){
        $errors = [];
        var_dump(isset($_FILES['picture']));
        var_dump($_FILES);
        if ($_FILES['picture']['size'] > 0){
            if (!in_array($_FILES['picture']['type'],moto::$allowedimage)){
                $errors['picture'] = 'veuiller renseigner un format valide ';
            }elseif ($_FILES['picture']['error'] != 0){
                $errors['picture'] = 'une erreure est surevenue';
            }elseif ($_FILES['picture']['size']>2097152){
                $errors['picture'] = "l'image est trop grosse";
            }
        }
        if(empty($_POST['mark'])){
            $errors['mark'] = 'vueillez indiquer une marque';
        }
        if(empty($_POST['model'])){
            $errors['model'] = 'vueillez indiquer un modele';
        }
        if(empty($_POST['type'])){
            $errors['type'] = 'vueillez indiquer un type';
        }elseif (!in_array($_POST['type'],moto::$allowedtype)){
            $errors['type'] = 'type invalide';
        }
        return $errors;
    }

    public function getbytype($type)
    {
        $empty = false;
        $allmotos = $this->motoManager->getbytype($type);
        if(!$allmotos){
            $empty = true;
            $message = 'il n\'y a aucune moto d\'enregistré de ce type';
        }
        require 'view/list.php';
    }

}