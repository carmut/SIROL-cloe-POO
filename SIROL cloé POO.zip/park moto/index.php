<?php
    require 'loader.php';
    if (!empty($_SESSION)){
        if(empty($_GET)){
            header('Location: index.php?controller=motos&action=list');
        }
        if($_GET['controller'] == 'motos' && !empty($_GET['action'])){
            $controller  =new motoController();
            if ($_GET['action'] == 'list' && isset($_GET['type'])){
                if (in_array($_GET['type'],moto::$allowedtype)){
                    $controller->getbytype($_GET['type']);
                }else{
                    $controller->getallmoto();
                }
            }elseif ($_GET['action'] == 'list'){
                $controller->getallmoto();
            }
            elseif ($_GET['action'] == 'detail' && array_key_exists('id',$_GET)){
                $controller->getdetail($_GET['id']);
            }
            elseif ($_GET['action'] == 'delete' && array_key_exists('id',$_GET)){
                $controller->delete($_GET['id']);
            }
            elseif ($_GET['action'] == 'add'){
                $controller->add();
            }else{
                header('Location: index.php?controller=security&action=404');
            }
        }elseif ($_GET['controller'] == 'security' && !empty($_GET['action'])){
            $controller  =new securityController();
            if ($_GET['action'] == 'logout'){
                $controller->logout();
            }else{
                $controller->page_non_trouve();
            }
        }else{
            header('Location: index.php?controller=security&action=404');
        }
    }elseif ($_GET['controller'] == 'security' && $_GET['action'] == 'login'){
        $controller  =new securityController();
        $controller->login();
    }else{
        header('Location: index.php?controller=security&action=login');
    }










