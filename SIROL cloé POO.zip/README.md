__construct();

__construct() est appellé l'ors de la creation d'un objet , 
il permet d'effectuer des action a ce moment la ; 
cette methode magique doit etre definie en public sinon une erreur est retrourner


exemple (code) : 

<?php 
	class exemple{
		public $test1;
		private $test2;
		
		public function __construct($valeur1,$valeur2){
			$this->test1 = $valeur1;
			$this->test2 = $valeur2;
		}
	}
	$test = new exemple(369,963);
	var_dump($test);
?>

---------------------------------------------------------------------------------

__sleep();

serialize() est le declencheur de __sleep() , 
__sleep() sera utiliser avant la serialisation ; 
elle est supposer retourner un tableau avec le nom des variables à serialiser  
si rien n'est retouner rien ne sera serialiser , et une rerreur sera retourner 


exemple (code) : 

<?php 
	class exemple{
		public $test1 = 1;
		private $test2 = 2;
		private $time_sleep;
		
		public function __sleep(){
			$this->time_sleep = new DateTime();
			return array('test1','test2','time_sleep');
		}
	}

	
	$test = new exemple();
	$backup = serialize($test);
	var_dump($backup);
?>

---------------------------------------------------------------------------------

__wakeup();

__wakeup() de son cote est declencher par unserialize() ; 
son role principale est de restaurer la connexion a la base de donnée si besoin ,
et d'effectuer les tache de réinitialisation; 



exemple (code) : 

<?php 
	class exemple{
		public $test1 = 1;
		private $test2 = 2;
		private $time_sleep;
		private $time_wake_up;
		
		public function __wakeup(){
			$this->time_wake_up = new DateTime();
		}

		public function __sleep(){
			$this->time_sleep = new DateTime();
			return array('test1','test2','time_sleep');
		}
	}

	$test = new exemple();
	$backup = serialize($test);
	var_dump($backup);
	$test = unserialize($backup);
	var_dump($test);
?>

---------------------------------------------------------------------------------

__set();

__set() vas etre utiliser quand on essaye d'ecrire des données dans une variable inexistante ou innacessible (privées ou protégées)
grace a cette fonction on vas generalement definir la donnée dans un tableau pour la stocker temporairerment


exemple (code) : 

<?php 
	class exemple{
		public $test1 = 1;
		private $test2 = 2;
		private $temporaire = [];
		
		public function __set($name,$value){
			$this->temporaire[$name] = $value;
		}
	}

	$test = new exemple();
	$test->test3 = 3;
	var_dump($test);
?>

---------------------------------------------------------------------------------

__get();

__get() est declencher par une tentative d'obtenir des donnée soit inexistante ou innacessible (privées ou protégées)
son role vas etre d'effectuer des actions quand elle est enclencher , 
comme aller cherchert si la variable existe dans un tableau de stockage de donnée temporaire



exemple (code) : 

<?php 
	class exemple{
		public $test1 = 1;
		private $test2 = 2;
		private $temporaire = [];

		public function __get($name){
			if (array_key_exists($name, $this->temporaire)) {
            			return $this->temporaire[$name];
        		}else{
				return ('variable '. $name . ' non définie');
			}
		}

		public function __set($name,$value){
			$this->temporaire[$name] = $value;
		}
	}

	$test = new exemple();
	$test->test3 = 3;
	var_dump($test);

	echo $test->test3,'<br>';
	echo $test->test4;
?>

